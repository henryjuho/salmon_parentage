setwd("C:/Users/msinclai/Documents_C/phd_project/")
library(data.table)
library(stringi)
library(dplyr)

data1=fread("C:/Users/msinclai/Documents_C/phd_project/tenojoki.forAF_020818.txt") ###change this 

data1[,2:ncol(data1)] = as.data.table(lapply(data1[,2:ncol(data1)], function(x) gsub("(.)(.)", "\\1 \\2",x, perl = T)))
###now recode the sex locus (0 coded as "homozygote for allele 1", 1 coded as "homozygote for allele 2")
data1[,2:ncol(data1)] = as.data.table(lapply(data1[,2:ncol(data1)], function(x) gsub("1", "2 2",x, perl = T))) #males
data1[,2:ncol(data1)] = as.data.table(lapply(data1[,2:ncol(data1)], function(x) gsub("0", "1 1",x, perl = T))) #females
#and now replace NAs with 0's for plink
data1[is.na(data1)]="0 0"

###now make the first 6 columns of a plink .ped file
#1.Family ID
#2.Individual ID
#3.Paternal ID
#4.Maternal ID
#5.Sex (1=male; 2=female; other=unknown)
#6.Phenotype
col1=data1$V1
col2=data1$V1
col3=rep(0, nrow(data1)) #unknown
col6=rep(-9, nrow(data1))
ped6cols=data.table(col1, col2, col3, col3, col3, col6)

PEDfile=data.table(ped6cols, data1[,-1])
fwrite(PEDfile, "C:/Users/msinclai/Documents_C/phd_project/tenojoki.forAF_020818.ped", col.names = F, row.names = F, sep=" ", quote = F) ###change this

###Now make the corresponding .map file (I can change this to incorporate position and chromosome if you have this info.)

#Chromosome code
#Variant ID
#Position in morgans or centimorgans
#Physical position

map.col1=rep(0, ncol(data1)-1) #-1 to get rid of the col with ID names
map.col2=colnames(data1)[-1]
map.col3=rep(0, ncol(data1)-1)
map.col4=rep(0, ncol(data1)-1)

MAPfile=data.table(map.col1, map.col2, map.col3, map.col4)
fwrite(MAPfile, "C:/Users/msinclai/Documents_C/phd_project/tenojoki.forAF_020818.map", col.names = F, row.names = F, sep="\t", quote = F) ###change this

#to get the corresponding binary file .raw format for sequoia I have used command line plink2 using the following command:
#plink --file tenojoki.forAF_020818 --chr-set 29 --keep-allele-order --recodeA --out tenojoki.forAF_020818

